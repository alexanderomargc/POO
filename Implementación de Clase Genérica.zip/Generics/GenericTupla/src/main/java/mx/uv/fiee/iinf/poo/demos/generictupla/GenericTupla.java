package mx.uv.fiee.iinf.poo.demos.generictupla;

public class GenericTupla <T> {
 
   private T first;
   private T second;
    int length;
  
  
  public GenericTupla (T first, T second) { //
    this.first = first;
    this.second = second;
  }


    GenericTupla() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  public T getFirst () {
    return first;
  }

  public  T getSecond () {
    return second;
  }

  @Override
  public String toString () {
    return String.format ("(%s, %s)", first.toString (), second.toString ());
  }

    void add(String santiago_Bernabéu, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    boolean get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }



}

